public class Machine {

    public Position location;

}