import java.util.Collection;

public class Ship extends Machine {

    private Collection<Sailor> sailors;

public Ship(int longitude, int latitude){
    location = new Position(longitude, latitude);
}



}

