public class Board {

    private ArrayList<Fleet> fleets;


public Board(){
    this.board = new ArrayList<Fleet>();
}
}